package test;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Calendar;
import java.util.List;

import org.apache.avro.file.DataFileReader;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericDatumReader;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.io.DatumReader;
import org.apache.flume.Context;
import org.apache.flume.Event;
import org.apache.flume.event.EventBuilder;
import org.apache.flume.serialization.EventSerializer;
import org.apache.flume.serialization.EventSerializerFactory;
import org.junit.Assert;
import org.junit.Test;

import com.google.common.base.Charsets;
import com.google.common.collect.Lists;

import com.dereksdata.cef.CefAvroEventSerializer;

public class TestCefAvroEventSerializer {

	@Test
	public void test() throws FileNotFoundException, IOException {
		//Test a file containing a single junk line
		testCef("src/test/resources/TestData-CefEvents-1JunkLine.done.cef");
		//Test a file containing escaped values
		testCef("src/test/resources/TestData-CefEvents-Escaped-Values.done.cef");
		//Test a file containing junk binary data
		testCef("src/test/resources/TestData-CefEvents-JunkBinary.bin");
		//Test a larger clean CEF file containing - throughput test
		testCef("src/test/resources/TestData-CefEvents-128MB.done.cef");
	}

	public void testCef(final String testCefFileName) throws FileNotFoundException, IOException {

		// 1) create a java calendar instance
		final Calendar start = Calendar.getInstance();

		// create the file, write some data
		final File cefFile = new File(testCefFileName);
		final File avroFile = new File(testCefFileName + ".avro");
		final File verifyFile = new File(testCefFileName + ".verify");
		final OutputStream out = new FileOutputStream(avroFile);
		final String builderName = CefAvroEventSerializer.Builder.class.getName();

		final Context ctx = new Context();
		ctx.put("syncInterval", "4096");
		ctx.put("compressionCodec", "snappy");

		final EventSerializer serializer = EventSerializerFactory.getInstance(builderName, ctx, out);
		serializer.afterCreate(); // must call this when a file is newly created

		long eventCount = 0;
		final List<Event> events = generateCefEvents(cefFile);
		for (final Event e : events) {
			serializer.write(e);
			eventCount++;
			System.out.print("Event: " + Long.toString(eventCount) + "\r");
		}
		serializer.flush();
		serializer.beforeClose();
		out.flush();
		out.close();
		System.out.println();

		final long secs = (Calendar.getInstance().getTimeInMillis() - start.getTimeInMillis()) / 1000;
		final long eps = eventCount / secs;
		System.out.println("Time taken to serialize: " + secs + "s");
		System.out.println("Events per second (eps): " + eps);

		// now try to read the file back and write to an output file
		final BufferedWriter outputFileWriter = new BufferedWriter(new FileWriter(verifyFile));

		final DatumReader<GenericRecord> reader = new GenericDatumReader<GenericRecord>();
		final DataFileReader<GenericRecord> fileReader = new DataFileReader<GenericRecord>(avroFile, reader);

		final GenericRecord record = new GenericData.Record(fileReader.getSchema());
		int numEvents = 0;
		while (fileReader.hasNext()) {
			fileReader.next(record);
			int fieldCount = 0;
			for (int i = 0; i < record.getSchema().getFields().size(); i++) {
				if (record.get(i) != null) {
					if (fieldCount != 0)
						outputFileWriter.write(" ");
					outputFileWriter.write(record.getSchema().getFields().get(i).name() + "=" + record.get(i));
					fieldCount++;
				}
			}
			if (fieldCount > 0)
				outputFileWriter.write("\n");
			numEvents++;
		}

		fileReader.close();
		outputFileWriter.close();
		System.out.println("Written events=" + events.size() + " Read events from Avro=" + numEvents);
		Assert.assertEquals("Correct data should have found a total of " + events.size() + " events", events.size(),
				numEvents);
	}

	private List<Event> generateCefEvents(final File cefFile) throws IOException {
		final List<Event> list = Lists.newArrayList();

		Event e;

		final BufferedReader br = new BufferedReader(new FileReader(cefFile));
		String line = null;
		while ((line = br.readLine()) != null) {
			e = EventBuilder.withBody(line, Charsets.UTF_8);
			list.add(e);
		}
		br.close();

		return list;
	}

}
