/**
 * Flume Serializer for Arcsight CEF files to Avro  
 *
 * @SINCE 1.0
 * @AUTHOR dereksdata.com
 * @VERSION 2.5
 */
package com.dereksdata.cef;