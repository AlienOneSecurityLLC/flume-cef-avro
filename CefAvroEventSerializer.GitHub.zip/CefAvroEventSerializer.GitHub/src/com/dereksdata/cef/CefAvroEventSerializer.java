package com.dereksdata.cef;

import com.google.common.base.Charsets;

import java.io.IOException;
import java.io.OutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.TimeZone;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.avro.Schema;
import org.apache.avro.Schema.Field;
import org.apache.flume.Context;
import org.apache.flume.Event;
import org.apache.flume.serialization.AbstractAvroEventSerializer;
import org.apache.flume.serialization.EventSerializer;
import org.joda.time.DateTimeZone;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dereksdata.cef.CefAvroEvent; 

public class CefAvroEventSerializer
extends AbstractAvroEventSerializer<CefAvroEvent> {
	private static final Logger logger =
			LoggerFactory.getLogger(CefAvroEventSerializer.class);

	private final OutputStream out;
	private final static TreeMap<String,String> cefShortKeys = new TreeMap<String,String>(String.CASE_INSENSITIVE_ORDER);
	private final static TreeMap<String,Integer> cefStringLengths = new TreeMap<String,Integer>(String.CASE_INSENSITIVE_ORDER);
	private final static HashSet<String> cefPrefixKeys = new HashSet<String>();
	private final static HashSet<String> cefTimestampKeys = new HashSet<String>();
	private final int IMPALA_MAX_STRING_SIZE = 32767;

	// Build caches
	private TreeMap<CharSequence ,DateTimeZone> timeZoneCache = new  TreeMap<CharSequence,DateTimeZone>();
	private ArrayList<CharSequence> timeZoneCacheInvalid = new  ArrayList<CharSequence>();
	private final ArrayList<String> columnNames = new ArrayList<String>();
	private final ArrayList<String> columnTypes = new ArrayList<String>();
	
	// Setup CEF mapping objects
	// All Avro column/field names are written as lowercase due to Hive/Impala forcing lowercase instead of using case insensitivity
	private static final Pattern pExtensionValues = Pattern.compile("(?:_+)?([\\w.:~_,|%+-\\[\\]]+)=(.*?(?=(?:\\s[\\w.:~_,|%+-\\[\\]]+=|$)))");

	static
	{
		cefShortKeys.put("agt","agentaddress");
		cefShortKeys.put("ahost","agenthostname");
		cefShortKeys.put("aid","agentid");
		cefShortKeys.put("amac","agentmacaddress");
		cefShortKeys.put("art","agentreceipttime");
		cefShortKeys.put("atz","agenttimezone");
		cefShortKeys.put("at","agenttype");
		cefShortKeys.put("av","agentversion");
		cefShortKeys.put("app","applicationprotocol");
		cefShortKeys.put("cnt","baseeventcount");
		cefShortKeys.put("in","bytesin");
		cefShortKeys.put("out","bytesout");
		cefShortKeys.put("catdt","categorydevicetype");
		cefShortKeys.put("dst","destinationaddress");
		cefShortKeys.put("dlat","destinationgeolatitude");
		cefShortKeys.put("dlong","destinationgeolongitude");
		cefShortKeys.put("dhost","destinationhostname");
		cefShortKeys.put("dmac","destinationmacaddress");
		cefShortKeys.put("dntdom","destinationntdomain");
		cefShortKeys.put("dpt","destinationport");
		cefShortKeys.put("dpid","destinationprocessid");
		cefShortKeys.put("dproc","destinationprocessname");
		cefShortKeys.put("duid","destinationuserid");
		cefShortKeys.put("duser","destinationusername");
		cefShortKeys.put("dpriv","destinationuserprivileges");
		cefShortKeys.put("act","deviceaction");
		cefShortKeys.put("dvc","deviceaddress");
		cefShortKeys.put("cfp1","devicecustomfloatingpoint1");
		cefShortKeys.put("cfp1label","devicecustomfloatingpoint1label");
		cefShortKeys.put("cfp2","devicecustomfloatingpoint2");
		cefShortKeys.put("cfp2label","devicecustomfloatingpoint2label");
		cefShortKeys.put("cfp3","devicecustomfloatingpoint3");
		cefShortKeys.put("cfp3label","devicecustomfloatingpoint3label");
		cefShortKeys.put("cfp4","devicecustomfloatingpoint4");
		cefShortKeys.put("cfp4label","devicecustomfloatingpoint4label");
		cefShortKeys.put("c6a1","devicecustomipv6address1");
		cefShortKeys.put("c6a1label","devicecustomipv6address1label");
		cefShortKeys.put("c6a2","devicecustomipv6address2");
		cefShortKeys.put("c6a2label","devicecustomipv6address2label");
		cefShortKeys.put("c6a3","devicecustomipv6address3");
		cefShortKeys.put("c6a3label","devicecustomipv6address3label");
		cefShortKeys.put("c6a4","devicecustomipv6address4");
		cefShortKeys.put("c6a4label","devicecustomipv6address4label");
		cefShortKeys.put("cn1","devicecustomnumber1");
		cefShortKeys.put("cn1label","devicecustomnumber1label");
		cefShortKeys.put("cn2","devicecustomnumber2");
		cefShortKeys.put("cn2label","devicecustomnumber2label");
		cefShortKeys.put("cn3","devicecustomnumber3");
		cefShortKeys.put("cn3label","devicecustomnumber3label");
		cefShortKeys.put("cn4","devicecustomnumber4");
		cefShortKeys.put("cn4label","devicecustomnumber4label");
		cefShortKeys.put("cn5","devicecustomnumber5");
		cefShortKeys.put("cn5label","devicecustomnumber5label");
		cefShortKeys.put("cn6","devicecustomnumber6");
		cefShortKeys.put("cn6label","devicecustomnumber6label");
		cefShortKeys.put("cs1","devicecustomstring1");
		cefShortKeys.put("cs1label","devicecustomstring1label");
		cefShortKeys.put("cs2","devicecustomstring2");
		cefShortKeys.put("cs2label","devicecustomstring2label");
		cefShortKeys.put("cs3","devicecustomstring3");
		cefShortKeys.put("cs3label","devicecustomstring3label");
		cefShortKeys.put("cs4","devicecustomstring4");
		cefShortKeys.put("cs4label","devicecustomstring4label");
		cefShortKeys.put("cs5","devicecustomstring5");
		cefShortKeys.put("cs5label","devicecustomstring5label");
		cefShortKeys.put("cs6","devicecustomstring6");
		cefShortKeys.put("cs6label","devicecustomstring6label");
		cefShortKeys.put("cat","deviceeventcategory");
		cefShortKeys.put("dvchost","devicehostname");
		cefShortKeys.put("dvcmac","devicemacaddress");
		cefShortKeys.put("dvcpid","deviceprocessid");
		cefShortKeys.put("dtz","devicetimezone");
		cefShortKeys.put("domeid","domainexternalid");
		cefShortKeys.put("domid","domainid");
		cefShortKeys.put("domrid","domainreferenceid");
		cefShortKeys.put("domuri","domainuri");
		cefShortKeys.put("end","endtime");
		cefShortKeys.put("outcome","eventoutcome");
		cefShortKeys.put("fname","filename");
		cefShortKeys.put("fsize","filesize");
		cefShortKeys.put("msg","message");
		cefShortKeys.put("mrt","managerreceipttime");
		cefShortKeys.put("rt","receipttime");
		cefShortKeys.put("request","requesturl");
		cefShortKeys.put("src","sourceaddress");
		cefShortKeys.put("slat","sourcegeolatitude");
		cefShortKeys.put("slong","sourcegeolongitude");
		cefShortKeys.put("shost","sourcehostname");
		cefShortKeys.put("smac","sourcemacaddress");
		cefShortKeys.put("sntdom","sourcentdomain");
		cefShortKeys.put("spt","sourceport");
		cefShortKeys.put("spid","sourceprocessid");
		cefShortKeys.put("sproc","sourceprocessname");
		cefShortKeys.put("suid","sourceuserid");
		cefShortKeys.put("suser","sourceusername");
		cefShortKeys.put("spriv","sourceuserprivileges");
		cefShortKeys.put("start","starttime");
		cefShortKeys.put("proto","transportprotocol");
	}
	
	static
	{
		cefStringLengths.put("applicationProtocol",31);
		cefStringLengths.put("categoryBehavior",1023);
		cefStringLengths.put("categoryDeviceGroup",1023);
		cefStringLengths.put("categoryObject",1023);
		cefStringLengths.put("categoryOutcome",1023);
		cefStringLengths.put("categorySignificance",1023);
		cefStringLengths.put("categoryTechnique",1023);
		cefStringLengths.put("cryptoSignature",512);
		cefStringLengths.put("destinationDnsDomain",255);
		cefStringLengths.put("destinationHostName",1023);
		cefStringLengths.put("destinationNtDomain",255);
		cefStringLengths.put("destinationProcessName",1023);
		cefStringLengths.put("destinationServiceName",1023);
		cefStringLengths.put("destinationUserId",1023);
		cefStringLengths.put("destinationUserName",1023);
		cefStringLengths.put("destinationUserPrivileges",1023);
		cefStringLengths.put("deviceAction",63);
		cefStringLengths.put("deviceAddress",16);
		cefStringLengths.put("deviceCustomFloatingPoint1Label",1023);
		cefStringLengths.put("deviceCustomFloatingPoint2Label",1023);
		cefStringLengths.put("deviceCustomFloatingPoint3Label",1023);
		cefStringLengths.put("deviceCustomFloatingPoint4Label",1023);
		cefStringLengths.put("deviceCustomIPv6Address1Label",1023);
		cefStringLengths.put("deviceCustomIPv6Address2Label",1023);
		cefStringLengths.put("deviceCustomIPv6Address3Label",1023);
		cefStringLengths.put("deviceCustomIPv6Address4Label",1023);
		cefStringLengths.put("deviceCustomNumber1Label",1023);
		cefStringLengths.put("deviceCustomNumber2Label",1023);
		cefStringLengths.put("deviceCustomNumber3Label",1023);
		cefStringLengths.put("deviceCustomNumber4Label",1023);
		cefStringLengths.put("deviceCustomNumber5Label",1023);
		cefStringLengths.put("deviceCustomNumber6Label",1023);
		cefStringLengths.put("deviceCustomString1",1023);
		cefStringLengths.put("deviceCustomString1Label",1023);
		cefStringLengths.put("deviceCustomString2",1023);
		cefStringLengths.put("deviceCustomString2Label",1023);
		cefStringLengths.put("deviceCustomString3",1023);
		cefStringLengths.put("deviceCustomString3Label",1023);
		cefStringLengths.put("deviceCustomString4",1023);
		cefStringLengths.put("deviceCustomString4Label",1023);
		cefStringLengths.put("deviceCustomString5",1023);
		cefStringLengths.put("deviceCustomString5Label",1023);
		cefStringLengths.put("deviceCustomString6",1023);
		cefStringLengths.put("deviceCustomString6Label",1023);
		cefStringLengths.put("deviceDnsDomain",255);
		cefStringLengths.put("deviceDomain",1023);
		cefStringLengths.put("deviceEventCategory",1023);
		cefStringLengths.put("deviceEventClassId",1023);
		cefStringLengths.put("deviceExternalId",255);
		cefStringLengths.put("deviceFacility",1023);
		cefStringLengths.put("deviceHostName",100);
		cefStringLengths.put("deviceInboundInterface",15);
		cefStringLengths.put("deviceOutboundInterface",15);
		cefStringLengths.put("devicePayloadId",128);
		cefStringLengths.put("deviceProcessName",1023);
		cefStringLengths.put("deviceProduct",63);
		cefStringLengths.put("deviceSeverity",63);
		cefStringLengths.put("deviceTimeZone",255);
		cefStringLengths.put("deviceVendor",63);
		cefStringLengths.put("deviceVersion",31);
		cefStringLengths.put("externalId",40);
		cefStringLengths.put("fileHash",255);
		cefStringLengths.put("fileId",1023);
		cefStringLengths.put("fileName",1023);
		cefStringLengths.put("filePath",1023);
		cefStringLengths.put("filePermission",1023);
		cefStringLengths.put("fileType",1023);
		cefStringLengths.put("message",1023);
		cefStringLengths.put("oldFileHash",255);
		cefStringLengths.put("oldFileId",1023);
		cefStringLengths.put("oldFileName",1023);
		cefStringLengths.put("oldFilePath",1023);
		cefStringLengths.put("oldFilePermission",1023);
		cefStringLengths.put("oldFileType",1023);
		cefStringLengths.put("proto",31);
		cefStringLengths.put("rawEvent",4000);
		cefStringLengths.put("requestClientApplication",1023);
		cefStringLengths.put("requestContext",2048);
		cefStringLengths.put("requestCookies",1023);
		cefStringLengths.put("requestMethod",1023);
		cefStringLengths.put("requestUrl",1023);
		cefStringLengths.put("sourceDnsDomain",255);
		cefStringLengths.put("sourceHostName",1023);
		cefStringLengths.put("sourceNtDomain",255);
		cefStringLengths.put("sourceServiceName",1023);
		cefStringLengths.put("sourceUserId",1023);
		cefStringLengths.put("sourceUserName",1023);
		cefStringLengths.put("sourceUserPrivileges",1023);
		cefStringLengths.put("transportProtocol",31);
	}

	static
	{
		cefPrefixKeys.add("cefversion");
		cefPrefixKeys.add("devicevendor");
		cefPrefixKeys.add("deviceproduct");
		cefPrefixKeys.add("deviceversion");
		cefPrefixKeys.add("signature");
		cefPrefixKeys.add("name");
		cefPrefixKeys.add("severity");
	}

	static
	{
		cefTimestampKeys.add("agentreceipttime");
		cefTimestampKeys.add("devicecustomdate1");
		cefTimestampKeys.add("devicecustomdate2");
		cefTimestampKeys.add("devicereceipttime");
		cefTimestampKeys.add("endtime");
		cefTimestampKeys.add("eventannotationendtime");
		cefTimestampKeys.add("eventannotationmanagerreceipttime");
		cefTimestampKeys.add("eventannotationmodificationtime");
		cefTimestampKeys.add("eventannotationstageupdatetime");
		cefTimestampKeys.add("filecreatetime");
		cefTimestampKeys.add("filemodificationtime");
		cefTimestampKeys.add("flexdate1");
		cefTimestampKeys.add("managerreceipttime");
		cefTimestampKeys.add("oldfilecreatetime");
		cefTimestampKeys.add("oldfilemodificationtime");
		cefTimestampKeys.add("receipttime");
		cefTimestampKeys.add("starttime");
	}

	public CefAvroEventSerializer(OutputStream out) throws IOException {
		this.out = out;
		for(Field f : CefAvroEvent.SCHEMA$.getFields()){
			this.columnNames.add(f.name().toLowerCase());
			this.columnTypes.add(f.schema().toString().toLowerCase());
		}    
	}

	@Override
	protected OutputStream getOutputStream() {
		return out;
	}

	@Override
	protected Schema getSchema() {
		return CefAvroEvent.SCHEMA$;
	}

	@Override
	protected CefAvroEvent convert(Event event) {
		String strLine = new String(event.getBody(), Charsets.UTF_8);
		CefAvroEvent cav = new CefAvroEvent();
		if ( strLine.length() == 0) return cav;	
		if ( strLine.length() < 10) 
		{
			// Only trim and check for likely empty line
			strLine = strLine.trim();
			if ( strLine.length() == 0) return cav;	
		}

		// Read the prefix and populate the remainder of the extension
		String[] prefixAndContent = strLine.split("(?<!\\\\)\\|");
		if ( prefixAndContent.length < 8 )
		{			
			serializationError( "Unable to parse CEF prefix columns", strLine, cav);
			return cav;
		}
		String extension = "";
		for (int i = 0; i < prefixAndContent.length; i++)
		{
			switch (i) 
			{ 
			case 0: { break; } // 1.4 Drop all CEF Version tags as we are transforming to a known schema
			case 1: { setRowValue("deviceVendor", prefixAndContent[i], cav); break; }
			case 2: { setRowValue("deviceProduct", prefixAndContent[i], cav); break; }
			case 3: { setRowValue("deviceVersion", prefixAndContent[i], cav); break; }
			case 4: { setRowValue("signature", prefixAndContent[i], cav); break; }
			case 5: { setRowValue("name", prefixAndContent[i], cav); break; }
			case 6: { setRowValue("severity", prefixAndContent[i], cav); break; }
			case 7: { extension += prefixAndContent[i]; break; }
			default: { extension += "|" + prefixAndContent[i]; break; }
			}
		}

		// Read the extended attributes
		Matcher m = pExtensionValues.matcher(extension);
		int mCount = 0;
		while (m.find()) 
		{
			setRowValue(m.group(1),m.group(2), cav );		
			mCount++;
		}		
		if (mCount == 0)
		{
			serializationError( "Unable to parse CEF extension tags", strLine, cav);
			return cav;
		}

		// 1.4 Set the local time extended attributes 
		CheckLocalTime( cav );
		
		logger.debug("Serialized event as: {}", cav);

		return cav;
	}
	
	private void setXUnmapped( CefAvroEvent cav , String columnName, String value )
	{
		if ( (cav.getXunmapped() == null ) || (cav.getXunmapped() == "" ) ) 
		{
			cav.setXunmapped( columnName + "=" + value );
		}
		else
		{
			cav.setXunmapped( cav.getXunmapped() + " " + columnName + "=" + value );
		}
	}

	private void serializationError( String errorMessage, String strLine, CefAvroEvent cav )
	{	
		logger.warn("Serialization error " + errorMessage + " for record: " + strLeft(strLine,256));
		cav.setxreceipttimelocal(GetLocalTime( System.currentTimeMillis(),"UTC"));
		cav.setxagentreceipttimelocal(GetLocalTime(System.currentTimeMillis(),"UTC"));
		cav.setName(errorMessage + " Original record localed in rawEvent.");
		setXUnmapped( cav, "Serialization.Error", errorMessage);
		cav.setRawevent(strLeft( strLine, IMPALA_MAX_STRING_SIZE));
	}	
	
	private String strLeft( String sourceString, int numberOfCharacters)
	{
		return sourceString.substring(0, Math.min(sourceString.length(), numberOfCharacters));
	}
	
	private void setRowValue( String columnName, String value, CefAvroEvent cav  )
	{	
		if (value == null ) return;

		// Correct the column name for use
		columnName = columnName.toLowerCase();
		if ( cefShortKeys.containsKey(columnName) ) columnName = cefShortKeys.get(columnName);
		
		// 2.3 Get the string length 
		int maxStringLength = IMPALA_MAX_STRING_SIZE;
		if ( cefStringLengths.containsKey(columnName) ) maxStringLength = cefStringLengths.get(columnName);
		
		// 1.4 Drop all CEF Version tags as we are transforming to a known schema
		if (columnName.equalsIgnoreCase( "cefver")) 
		{
			return; 
		}

		int col;
		// 1.4 write unmapped tags to xUnmapped
		if (columnNames.contains(columnName))
		{
			col = columnNames.indexOf(columnName);
		}
		else
		{
			setXUnmapped( cav, columnName, value);
			return;
		}

		// Write out mapped values
		String colType = columnTypes.get(col);
		if (colType.contains("\"string\""))
		{
			// 2.3 trunc strings whose lengths exceed the specification and warn in the unmapped column
			if (value.length() > maxStringLength)
			{
				value = value.substring(0, maxStringLength);
				setXUnmapped( cav, "Serialization.Trimmed." + columnName, value);
			}
			
			// Revert escape characters
			if (value.contains("\\"))
			{						
				value = value.replace("\\|", "|");
				value = value.replace("\\=", "=");
				value = value.replace("\\\\","\\");				
			}
			cav.put(col,value);
		}
		else if ( colType.contains("\"tinyint\"") ||  colType.contains("\"smallint\"" ) || colType.contains("\"int\"" ) || colType.contains("\"integer\"" ) )
		{
			int fieldValue; 
			try 
			{  
				fieldValue= Integer.parseInt(value);			
				cav.put(col,fieldValue);
			} 
			catch(NumberFormatException e) 
			{			    	
			}			    
		}
		else if ( colType.contains("\"bigint\"") || colType.contains("\"long\"") )
		{
			long fieldValue = -1;		
			try 
			{
				fieldValue= Long.parseLong(value);	
				// 2.4.1 Sanity check the time field
				if ( cefTimestampKeys.contains(columnName) )
				{
					// If it's before 1970 or after 2050, set it to 1970-1-1:00:00
					if ( ( fieldValue < 0 ) || ( fieldValue > 2521843200000L ) )
					{
						setXUnmapped( cav, "Serialization.FixedTimestamp." + columnName, Long.toString(fieldValue));
						fieldValue = 0;
					}
				}
				cav.put(col,fieldValue);
			} 
			catch(NumberFormatException e) 
			{
				if ( cefTimestampKeys.contains(columnName) )
				{
					// This is a date fields expecting EPOCH time if it's in string format and the column is long (permitted by the ordinary CEF spec)
					// So convert it
					Date fieldDate = parseCefDate(value);
					if (fieldDate != null) 
					{
						fieldValue = fieldDate.getTime();
						cav.put(col,fieldValue);
					}
				}
			}
		}
		else if ( colType.contains("\"float\"") )
		{
			float fieldValue; 
			try 
			{  
				fieldValue= Float.parseFloat(value);		
				cav.put(col,fieldValue);
			} 
			catch(NumberFormatException e) 
			{ 
			}			   
		}
		else if ( colType.contains("\"double\"") )
		{
			double fieldValue; 
			try 
			{  
				fieldValue= Double.parseDouble(value);	
				cav.put(col,fieldValue);
			} 
			catch(NumberFormatException e) 
			{ 
			}			   
		}
		else if ( colType.contains("\"boolean\"") | colType.contains("\"bool\"") )
		{
			String boolVal = value;
			if ( boolVal.equalsIgnoreCase("true") || boolVal.equalsIgnoreCase("yes") || boolVal.equalsIgnoreCase("on")) cav.put(col,true);
			if ( boolVal.equalsIgnoreCase("false") || boolVal.equalsIgnoreCase("no") || boolVal.equalsIgnoreCase("off")) cav.put(col,false);
		}				
	}

	private Date parseCefDate(String dateString)
	{
		final String[] dateFormatStrings = {"MMM dd HH:mm:ss", "MMM dd HH:mm:ss.SSS zzz", "MMM dd HH:mm:ss.SSS", "MMM dd HH:mm:ss zzz", "MMM dd yyyy HH:mm:ss", "MMM dd yyyy HH:mm:ss.SSS zzz", "MMM dd yyyy HH:mm:ss.SSS", "MMM dd yyyy HH:mm:ss zzz"};
		for (String formatString : dateFormatStrings)
		{
			SimpleDateFormat sdf = new SimpleDateFormat(formatString);
			sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
			try
			{	        	
				Date parsedDate = sdf.parse(dateString);
				if (!formatString.contains("yyyy"))
				{
					// Perform a best effort for events where no year is supplied by using the current year
					Calendar nowTime = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
					Calendar eventTime = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
					eventTime.setTime(parsedDate);
					int year = nowTime.get(Calendar.YEAR);	        		
					if ((nowTime.get(Calendar.MONTH) - eventTime.get(Calendar.MONTH)) < 0 ) year--;  // Cater for new year processing (e.g. JAN2014 events on DEC2013)
					eventTime.set(Calendar.YEAR, year);
					parsedDate = eventTime.getTime();
				}
				return parsedDate ;
			}
			catch (ParseException e) {}
		}
		return null;
	}	

	private void CheckLocalTime(CefAvroEvent cav)
	{
		cav.setxreceipttimelocal(GetLocalTime(cav.getReceipttime(),cav.getDevicetimezone()));
		if (cav.getxreceipttimelocal() == null ) cav.setxreceipttimelocal(GetLocalTime(cav.getEndtime(),cav.getDevicetimezone()));
		if (cav.getxreceipttimelocal() == null ) cav.setxreceipttimelocal(GetLocalTime(cav.getStarttime(),cav.getDevicetimezone()));
		if (cav.getxreceipttimelocal() == null ) cav.setxreceipttimelocal(GetLocalTime(cav.getManagerreceipttime(),cav.getAgenttimezone()));
		if (cav.getxreceipttimelocal() == null ) cav.setxreceipttimelocal(GetLocalTime(cav.getAgentreceipttime(),cav.getAgenttimezone()));
		if (cav.getxreceipttimelocal() == null ) cav.setxreceipttimelocal(GetLocalTime( System.currentTimeMillis(),"UTC"));
		cav.setxagentreceipttimelocal(GetLocalTime(cav.getAgentreceipttime(),cav.getAgenttimezone()));
		if (cav.getxagentreceipttimelocal() == null ) cav.setxagentreceipttimelocal(GetLocalTime(System.currentTimeMillis(),"UTC"));
	}

	private Long GetLocalTime( Long epochTime, CharSequence timeZone)
	{
		if ( ( epochTime == null ) ) return null;
		if ( ( timeZone == null ) || ( timeZone == "" ) ) return epochTime;			
		if ( ( timeZone == "UTC" ) || ( timeZone == "GMT" ) ) return epochTime;
		if (timeZoneCacheInvalid.contains(timeZone)) return epochTime;	
		
		// Set the local timezone 
		DateTimeZone localTz;
		if (timeZoneCache.containsKey(timeZone))
		{
			localTz = timeZoneCache.get(timeZone);
		}
		else
		{
			try
			{				
				localTz = DateTimeZone.forID(timeZone.toString());
				timeZoneCache.put(timeZone, localTz);
			}
			catch (Exception e )
			{
				// Invalid timezone in CEF line
				timeZoneCacheInvalid.add(timeZone);				
				return epochTime;	
			}
		}
		
		try
		{
			return epochTime + localTz.getOffset(epochTime);
		}
		catch (Exception e )
		{
			// Invalid epoch time
			return epochTime;	
		}
	}

	public static class Builder implements EventSerializer.Builder {

		@Override
		public EventSerializer build(Context context, OutputStream out) {
			CefAvroEventSerializer writer = null;
			try {
				writer = new CefAvroEventSerializer(out);
				writer.configure(context);
			} catch (IOException e) {
				logger.error("Unable to parse schema file. Exception follows.", e);
			}
			return writer;
		}
	}
}